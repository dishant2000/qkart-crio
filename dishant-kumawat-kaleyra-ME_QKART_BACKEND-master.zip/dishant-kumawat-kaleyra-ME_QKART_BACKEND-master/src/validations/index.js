module.exports.userValidation = require("./user.validation");
module.exports.authValidation = require("./auth.validation");
module.exports.productValidation = require("./product.validation");
module.exports.cartValidation = require("./cart.validation");
