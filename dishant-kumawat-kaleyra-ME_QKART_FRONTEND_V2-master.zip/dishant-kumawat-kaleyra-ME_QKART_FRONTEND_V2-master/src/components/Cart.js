import {
  AddOutlined,
  RemoveOutlined,
  ShoppingCart,
  ShoppingCartOutlined,
} from "@mui/icons-material";
import { Button, IconButton, Stack,Typography } from "@mui/material";
import { Box } from "@mui/system";
import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import "./Cart.css";

// Definition of Data Structures used
/**
 * @typedef {Object} Product - Data on product available to buy
 *
 * @property {string} name - The name or title of the product
 * @property {string} category - The category that the product belongs to
 * @property {number} cost - The price to buy the product
 * @property {number} rating - The aggregate rating of the product (integer out of five)
 * @property {string} image - Contains URL for the product image
 * @property {string} _id - Unique ID for the product
 */

/**
 * @typedef {Object} CartItem -  - Data on product added to cart
 *
 * @property {string} name - The name or title of the product in cart
 * @property {string} qty - The quantity of product added to cart
 * @property {string} category - The category that the product belongs to
 * @property {number} cost - The price to buy the product
 * @property {number} rating - The aggregate rating of the product (integer out of five)
 * @property {string} image - Contains URL for the product image
 * @property {string} productId - Unique ID for the product
 */

/**
 * Returns the complete data on all products in cartData by searching in productsData
 *
 * @param { Array.<{ productId: String, qty: Number }> } cartData
 *    Array of objects with productId and quantity of products in cart
 *
 * @param { Array.<Product> } productsData
 *    Array of objects with complete data on all available products
 *
 * @returns { Array.<CartItem> }
 *    Array of objects with complete data on products in cart
 *
 */
export const generateCartItemsFrom = (cartData, productsData) => {
  let cartItems = [];
  cartData.forEach((item) => {
    let productObj = productsData.find((product) => {
      // console.log(product,item)
      return product._id === item.productId;
    });
    if (productObj) {
      let newItemObj = JSON.parse(JSON.stringify(productObj));
      // console.log(newItemObj)
      newItemObj.qty = item.qty;
      cartItems.push(newItemObj);
    }
  });
  // console.log("from cart =",cartItems);
  return cartItems;
};

/**
 * Get the total value of all products added to the cart
 *
 * @param { Array.<CartItem> } items
 *    Array of objects with complete data on products added to the cart
 *
 * @returns { Number }
 *    Value of all items in the cart
 *
 */
export const getTotalCartValue = (items = []) => {
  let total = 0;
  items.forEach((item) => {
    total += item.cost * item.qty;
  });
  return total;
};

/**
 * Component to display the current quantity for a product and + and - buttons to update product quantity on cart
 *
 * @param {Number} value
 *    Current quantity of product in cart
 *
 * @param {Function} handleAdd
 *    Handler function which adds 1 more of a product to cart
 *
 * @param {Function} handleDelete
 *    Handler function which reduces the quantity of a product in cart by 1
 *
 *
 */
const ItemQuantity = ({ isReadOnly, value, handleAdd, handleDelete }) => {
  return (
    <Stack direction="row" alignItems="center">
      {isReadOnly ? null : (
        <IconButton size="small" color="primary" onClick={handleDelete}>
          <RemoveOutlined />
        </IconButton>
      )}
      <Box padding="0.5rem" data-testid="item-qty">
        {isReadOnly ? "Qty: " : null}
        {value}
      </Box>
      {isReadOnly ? null : (
        <IconButton size="small" color="primary" onClick={handleAdd}>
          <AddOutlined />
        </IconButton>
      )}
    </Stack>
  );
};

/**
 * Component to display the Cart view
 *
 * @param { Array.<Product> } products
 *    Array of objects with complete data of all available products
 *
 * @param { Array.<Product> } items
 *    Array of objects with complete data on products in cart
 *
 * @param {Function} handleDelete
 *    Current quantity of product in cart
 *
 *
 */
const Cart = ({ isReadOnly, products, items = [], handleQuantity }) => {
  const [cartDetailedItems, setCartDetailedItems] = useState([]);
  const history = useHistory();
  useEffect(() => {
    // console.log("from cart",products, isReadOnly,items);
    if (items.length) {
      // console.log("yae chala cart",items)
      let cartItems = generateCartItemsFrom(items, products);
      setCartDetailedItems(cartItems);
    }
  }, [items, products]);

  // useEffect(()=>{console.log("this runs",cartDetailedItems)},[cartDetailedItems]);

  // hadling delete and add cart items

  const handleAdd = (productId, qty) => {
    // console.log("from handle add cart = ", productId)
    handleQuantity(
      localStorage.getItem("token"),
      items,
      products,
      productId,
      qty + 1,
      { preventDuplicate: false }
    );
  };
  const handleDelete = (productId, qty) => {
    handleQuantity(
      localStorage.getItem("token"),
      items,
      products,
      productId,
      qty - 1,
      { preventDuplicate: false }
    );
  };
  // useEffect(()=>{},[cartDetailedItems])
  if (!items.length) {
    return (
      <Box className="cart empty">
        <ShoppingCartOutlined className="empty-cart-icon" />
        <Box color="#aaa" textAlign="center">
          Cart is empty. Add more items to the cart to checkout.
        </Box>
      </Box>
    );
  }

  return (
    <>
      <Box className="cart">
        {
          /* TODO: CRIO_TASK_MODULE_CART - Display view for each cart item with non-zero quantity */
          !isReadOnly && cartDetailedItems.length === 0
            ? null
            : cartDetailedItems.map((cartItem) => {
                return (
                  <Box
                    display="flex"
                    alignItems="flex-start"
                    padding="1rem"
                    key={cartItem._id}
                  >
                    <Box className="image-container">
                      <img
                        // Add product image
                        src={cartItem.image}
                        // Add product name as alt eext
                        alt=""
                        width="100%"
                        height="100%"
                      />
                    </Box>
                    <Box
                      display="flex"
                      flexDirection="column"
                      justifyContent="space-between"
                      height="6rem"
                      paddingX="1rem"
                    >
                      <div>{cartItem.name}</div>
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                      >
                        <ItemQuantity
                          value={cartItem.qty}
                          handleAdd={() => {
                            handleAdd(cartItem._id, cartItem.qty);
                          }}
                          handleDelete={() => {
                            handleDelete(cartItem._id, cartItem.qty);
                          }}
                        />
                        <Box padding="0.5rem" fontWeight="700">
                          ${cartItem.cost}
                        </Box>
                      </Box>
                    </Box>
                  </Box>
                );
              })
        }
        {isReadOnly
          ? items.map((item) => {
              return (
                <Box
                  display="flex"
                  alignItems="flex-start"
                  padding="1rem"
                  key={item._id}
                >
                  <Box className="image-container">
                    <img
                      // Add product image
                      src={item.image}
                      // Add product name as alt eext
                      alt=""
                      width="100%"
                      height="100%"
                    />
                  </Box>
                  <Box
                    display="flex"
                    flexDirection="column"
                    justifyContent="space-between"
                    height="6rem"
                    paddingX="1rem"
                  >
                    <div>{item.name}</div>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                    >
                      <ItemQuantity isReadOnly value={item.qty} />
                      <Box padding="0.5rem" fontWeight="700">
                        ${item.cost}
                      </Box>
                    </Box>
                  </Box>
                </Box>
              );
            })
          : null}

        <Box
          padding="1rem"
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box color="#3C3C3C" alignSelf="center">
            Order total
          </Box>
          <Box
            color="#3C3C3C"
            fontWeight="700"
            fontSize="1.5rem"
            alignSelf="center"
            data-testid="cart-total"
          >
            $
            {isReadOnly
              ? getTotalCartValue(items)
              : getTotalCartValue(cartDetailedItems)}
          </Box>
        </Box>
        {isReadOnly ? null : (
          <Box display="flex" justifyContent="flex-end" className="cart-footer">
            <Button
              color="primary"
              variant="contained"
              startIcon={<ShoppingCart />}
              className="checkout-btn"
              onClick={() => {
                history.push("/checkout");
              }}
            >
              Checkout
            </Button>
          </Box>
        )}
      </Box>
      {
        !isReadOnly ? null : <Box
          className = "cart"
          display = "flex"
          flexDirection = "column"
          justifyContent= "space-evenly"
          alignItems = "flex-start"
          px = {2}
          py = {4}
        >
          <Typography variant = "h6">Order Details</Typography>
          <Box className = "cart-row" width = "100%" my={2}>
            <Box>Products</Box>
            <Box>{items.length}</Box>
          </Box>
          <Box className = "cart-row" width = "100%" mb={2}>
            <Box element = "div">Subtotal</Box>
            <Box element = "div">${getTotalCartValue(items)}</Box>
          </Box>
          <Box className = "cart-row" width = "100%" mb={2}>
            <Box>Shiping</Box>
            <Box>$0</Box>
          </Box>
          <Box className = "cart-row" width = "100%" mb={2}>
          <Typography variant = "body1" fontWeight="600">Total</Typography>
          <Typography variant = "body1" fontWeight="600">${getTotalCartValue(items)}</Typography>
          </Box>
        </Box>
      }
    </>
  );
};

export default Cart;
