import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { Avatar, Button, Stack } from "@mui/material";
import Box from "@mui/material/Box";
import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import "./Header.css";

const Header = ({ children, hasHiddenAuthButtons }) => {
  const history = useHistory();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    let loggedIn =
      localStorage.getItem("username") && localStorage.getItem("token");
    if (loggedIn) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [isLoggedIn]);
  const handleLogout = () => {
    localStorage.clear();
    window.location.reload();
  };
  const renderAuthButtons = () => {
    if (isLoggedIn) {
      return (
        <Stack direction="row" spacing={2}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
            }}
          >
            <Avatar
              src="public/avatar.png"
              alt={localStorage.getItem("username")}
              sx={{ height: "32px", width: "32px", margin: "0 8px" }}
            ></Avatar>
            {localStorage.getItem("username")}
          </Box>

          <Button
            variant="text"
            onClick={() => {
              handleLogout();
            }}
          >
            LogOut
          </Button>
        </Stack>
      );
    } else {
      return (
        <Stack direction="row">
          <Button
            variant="text"
            color="success"
            onClick={() => {
              history.push("/login");
            }}
          >
            Login
          </Button>
          <Button
            variant="contained"
            color="success"
            onClick={() => {
              history.push("/register");
            }}
          >
            Register
          </Button>
        </Stack>
      );
    }
  };
  return (
    <Box className="header">
      <Box className="header-title">
        <img src="logo_light.svg" alt="QKart-icon"></img>
      </Box>
      <Box>{children ? children : null}</Box>
      <Box>
        {hasHiddenAuthButtons === true ? (
          <Button
            className="explore-button"
            startIcon={<ArrowBackIcon />}
            variant="text"
            onClick={() => {
              history.replace("/");
            }}
          >
            Back to explore
          </Button>
        ) : (
          renderAuthButtons()
        )}
      </Box>
    </Box>
  );
};

export default Header;
